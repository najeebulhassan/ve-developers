@include('layouts.header')

<title>@yield('title')</title>

@yield('content')

@include('layouts.footer')