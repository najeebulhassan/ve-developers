<?php if(\Request::is('/')): ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<?php echo $__env->make('layouts.header-2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<title><?php echo $__env->yieldContent('title'); ?></title>
<!-- <link rel="canonical" href="<?php echo $__env->yieldContent('canonical'); ?>"> -->
<!-- <link rel="stylesheet" href="style.css"> -->


<?php echo $__env->make('layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\workers-direct\resources\views/layouts/base.blade.php ENDPATH**/ ?>