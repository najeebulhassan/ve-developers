<a id="chat-circle-new"  class="btn btn-success zoom" href="<?php echo e(url('ask-us/')); ?>">
    <span style="font-size: 25px; color: white;position:absolute; top: 3px; left: 20px;">ASK US </span>
    <i class="fa fa-question-circle" style="font-size: 25px; color: white;position:absolute; top: 15px; right: 20px;" aria-hidden="true"></i>
</a><?php /**PATH C:\xampp\htdocs\workers-direct\resources\views/layouts/modal.blade.php ENDPATH**/ ?>