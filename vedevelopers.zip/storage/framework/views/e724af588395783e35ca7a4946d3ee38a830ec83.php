<!-- jp counter Wrapper Start -->
<div class="jp_counter_main_wrapper">
    <div class="container-fluid pl-0 pr-0">
        <div class="row">
            <div class="gc_counter_cont_wrapper_new col-md-2">
                <div class="count-description-new"> <span class="timer">52950</span><i class="slider_icon_size fa fa-plus"></i>
                    <h5 class="con1">WORKERS</h5>
                </div>
            </div>
            <div class="gc_counter_cont_wrapper_new col-md-2">
                <div class="count-description-new"> <span class="timer">98</span><i class="slider_icon_size fas fa-percent"></i>
                    <h5 class="con2">ENJOY WORK WITH US</h5>
                </div>
            </div>
            <div class="gc_counter_cont_wrapper_new col-md-2">
                <div class="count-description-new"> <span class="timer">92</span><i class="slider_icon_size fas fa-percent"></i>
                    <h5 class="con3">RETAINED WORKERS</h5>
                </div>
            </div>
            <div class="gc_counter_cont_wrapper_new col-md-2">
                <div class="count-description-new"> <span class="timer">572847</span><i class="slider_icon_size fa fa-plus"></i>
                    <h5 class="con4">WORKED HOURS</h5>
                </div>
            </div>
            <div class="gc_counter_cont_wrapper_new col-md-2">
                <div class="count-description-new"> <span class="timer">1200</span><i class="slider_icon_size fa fa-plus"></i>
                    <h5 class="con4">CLIENTS</h5>
                </div>
            </div>
            <div class="gc_counter_cont_wrapper_new col-md-2">
                <div class="count-description-new"> <span class="timer">1434</span><i class="slider_icon_size fa fa-plus"></i>
                    <h5 class="con4">SITES</h5>
                </div>
            </div>
        </div>

    </div>
</div>
<!-- jp counter Wrapper End --><?php /**PATH C:\xampp\htdocs\workers-direct\resources\views/layouts/number-counter.blade.php ENDPATH**/ ?>